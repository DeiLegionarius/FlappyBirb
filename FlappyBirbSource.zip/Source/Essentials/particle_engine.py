import math
import random
import pygame

pygame.init()
screen = pygame.display.set_mode((1280, 720))

particles = []
particles_disabled = False

def PARTICLESDISABLEDCHECK():
    return particles_disabled

def DISABLEPARTICLES():
    global particles_disabled
    particles_disabled = True
    
def ENABLEPARTICLES():
    global particles_disabled
    particles_disabled = False
    
def CLEARPARTICLES():
    global particles
    particles = [] # I am the best programmer on earth, that's why God chose me, and he gave me divine intellect.

def calculateXYdir(axis, dirDegrees, distance):
    dirRad = math.radians(dirDegrees)
    if axis == "x":
        return distance * math.cos(dirRad)
    elif axis == "y":
        return distance * math.sin(dirRad)
        
def CREATEJUMPPARTICLES(location, amount, size, color, speed, currentTime, lifeTime, fading): # Location must be a rect 
    if particles_disabled:
        return
        
    global particles
    
    rangeInDegrees = [160, 70]
    
    startpointX = location.x
    startpointY = location.y + location.height
    distribution = int(location.width // amount)
    
    for rep in range(amount):
        
        particle = pygame.Rect(0, 0, size, size)
        particle.center = ((startpointX + (distribution * rep)) + size // 2), startpointY
        
        direction = rangeInDegrees[0] - (rangeInDegrees[1] * (rep / (amount - 1)))
        
        px = float(particle.centerx)  + 60
        py = float(particle.centery) - random.randint(1, 20)
        
        particles.append((particle, px, py, direction, color, speed, "JumpParticles", currentTime + lifeTime * 1000, 100, lifeTime * 1000, currentTime, fading))
        
def MOVE_AND_DRAW_PARTICLES(chosenCategory, dt, time, negative):
    if particles_disabled:
        return
        
    global particles
    if not particles:
        return
        
    particles_update = []
    
    if chosenCategory == "JumpParticles":
        for particle, px, py, direction, color, speed, category, deathTime, alpha, lifeTime, birthTime, fading in particles:
            if category == "JumpParticles" and time < deathTime:
                lifeFraction = (time - birthTime) / lifeTime
                tempsurf = pygame.Surface((particle.width, particle.height), pygame.SRCALPHA)
                tempsurf.fill((0, 0, 0, 0))   # fully transparent background
                rect_color = color
                if fading:
                    alpha = max(0, 255 * (1 - lifeFraction))
                    tempsurf.set_alpha(int(alpha))
                pygame.draw.rect(tempsurf, rect_color, tempsurf.get_rect())
                dx = calculateXYdir("x", direction, speed * dt)
                dy = calculateXYdir("y", direction, speed * dt)
                px += dx - negative * dt
                py += dy
                particle.center = (int(px), int(py))
                screen.blit(tempsurf, particle.topleft)
                particles_update.append((particle, px, py, direction, color, speed, category, deathTime, alpha, lifeTime, birthTime, fading))
    particles = particles_update

