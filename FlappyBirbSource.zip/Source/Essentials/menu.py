
import pygame
import os

pygame.font.init()
pygame.init()

info = [
    "Flappy Birb, Release v1.0.0, 1. December 2025",
    "Thank you for playing!",
    "github.com/DeiLegionarius/FlappyBirb/releases"
    ]

# a
# Text Configs
MM_font = pygame.font.SysFont('Source Sans', 80)
info_font = pygame.font.SysFont('Source Sans', 40)
MM_font_30 = pygame.font.SysFont('Source Sans', 50)
MM_buy_font = pygame.font.SysFont('Source Sans', 30)
MM_TitleFont = pygame.font.SysFont("Source Sans", 100)

backButton = pygame.Rect(0, 0, 200, 100)

def Speed_I_Need_A_Back_Button_My_Mom_Is_Kinda_Backbuttonless(screen, text, x, y):
    global backButton
    
    backBText = MM_font.render(text, False, ("white"))
    backBTextRect = backBText.get_rect(center=(x, y))
    backButton.center = (x, y)
    pygame.draw.rect(screen, "black", backButton)
    screen.blit(backBText, backBTextRect)

def CONSTRUCT_MENU(screen, MainMenuCover):
    global playButton, playBText, menuTitleText, menuTitleTextRect, playButton, playBTextRect, infoButton, infoBText, infoBTextRect, settingsButton
    screen.fill("aqua")
    screen.blit(MainMenuCover, (0, 0))
    
    playButton = pygame.Rect(0, 0, 200, 100)
    playBText = MM_font.render("PLAY", False, ("white"))
    playButton.center = (screen.get_width() // 2, screen.get_height() // 2 - 30)
    playBTextRect = playBText.get_rect(center=(screen.get_width() // 2, screen.get_height() // 2 - 30))
    pygame.draw.rect(screen, "black", playButton)
    screen.blit(playBText, playBTextRect.topleft)
    
    settingsButton = pygame.Rect(0, 0, 200, 100)
    settingsBText = MM_font_30.render("SETTINGS", False, ("White"))
    settingsButton.center = (screen.get_width() // 2, screen.get_height() // 2 + 100)
    settingsBTextRect = settingsBText.get_rect(center=(screen.get_width() // 2, screen.get_height() // 2 + 100))
    pygame.draw.rect(screen, "black", settingsButton)
    screen.blit(settingsBText, settingsBTextRect.topleft)
    
    infoButton = pygame.Rect(0, 0, 200, 100)
    infoButton.center = (screen.get_width() // 2, screen.get_height() // 2 + 230)
    infoBText = MM_font.render("INFO", False, ("white"))
    infoBTextRect = infoBText.get_rect(center=(screen.get_width() // 2, screen.get_height() // 2 + 230))
    pygame.draw.rect(screen, "black", infoButton)
    screen.blit(infoBText, infoBTextRect.topleft)
    
    menuTitleText = MM_TitleFont.render("Flappy Birb", False, ("black"))
    menuTitleTextRect = menuTitleText.get_rect(center=(screen.get_width() // 2, 100))
    screen.blit(menuTitleText, menuTitleTextRect.topleft)
    
def INFOSCREEN(screen):
    screen.fill("aqua")
    Speed_I_Need_A_Back_Button_My_Mom_Is_Kinda_Backbuttonless(screen, "BACK", screen.get_width() // 2, screen.get_height() // 2 + 300)
    counter = 1
    for text in info:
        infoText = info_font.render(text, False, ("black"))
        infoTextRect = infoText.get_rect(center=(screen.get_width() // 2, 100 * counter))
        screen.blit(infoText, infoTextRect.topleft)
        counter += 1
    
def SHOPINTERFACE(screen, asset_folder):
    # Current state of the shop:
    # if shop_exists():
    #   do_shop():
    # NameError: Dawg what is shop it still dont exist 😔
    # Replaced by settings...
    global buyButton, equipButton, nextPoly
    price = 1
    screen.fill("aqua")
    Speed_I_Need_A_Back_Button_My_Mom_Is_Kinda_Backbuttonless(screen, "BACK", screen.get_width() - 130, screen.get_height() // 2 + 300)
    ComingSoonText = MM_font.render("Coming Soon!", False, ("black"))
    ComingSoonTextRect = ComingSoonText.get_rect(center=(screen.get_width() // 2, screen.get_height() // 2))
    screen.blit(ComingSoonText, ComingSoonTextRect)
    
    # 2 buttons, buy equip.
    buyButton = pygame.Rect(0, 0, 200, 100)
    buyBText = MM_buy_font.render(f"BUY ({price} coins)", False, ("White"))
    buyButton.center = (screen.get_width() // 2 - 230, screen.get_height() // 2 + 100)
    buyBTextRect = buyBText.get_rect(center=(screen.get_width() // 2 - 230, screen.get_height() // 2 + 100))
    pygame.draw.rect(screen, "green", buyButton)
    screen.blit(buyBText, buyBTextRect.topleft)
    
    equipButton = pygame.Rect(0, 0, 200, 100)
    equipBText = MM_font.render("EQUIP", False, ("White"))
    equipButton.center = (screen.get_width() // 2 + 230, screen.get_height() // 2 + 100)
    equipBTextRect = equipBText.get_rect(center=(screen.get_width() // 2 + 230, screen.get_height() // 2 + 100))
    pygame.draw.rect(screen, "gray", equipButton)
    screen.blit(equipBText, equipBTextRect.topleft)
    
    # next and previous triangles
    nextPoly = pygame.draw.polygon(screen, "black", [(screen.get_width() // 2 + 170, screen.get_height() // 2 - 350),(screen.get_width() // 2 + 170, screen.get_height() // 2 - 50),(screen.get_width() // 2 + 250, screen.get_height() // 2 - 200)] )
    
    # Preview frame and everything that goes with it (hopefuly)
    previewFrame = pygame.Rect(0, 0, 300, 300)
    previewFrame.center = (screen.get_width() // 2, screen.get_height() // 2 - 200)
    pygame.draw.rect(screen, "white", previewFrame)
    
def SETTINGSINTERFACE(screen, difficulty, FPS, particlesDisabled, debug_mode):
    global difficultyLeft, difficultyRight
    global fpsButton60, fpsButton144
    global particlesToggle, debugToggle

    screen.fill("aqua")
    Speed_I_Need_A_Back_Button_My_Mom_Is_Kinda_Backbuttonless(
        screen, "BACK",
        screen.get_width() - 130,
        screen.get_height() // 2 + 300
    )

    title = MM_TitleFont.render("Settings", False, "black")
    screen.blit(title, title.get_rect(center=(screen.get_width() // 2, 120)))

    y = 260

    # DIFFICULTY  ------------------------------------------
    label = MM_font_30.render("Difficulty:", False, "black")
    screen.blit(label, label.get_rect(center=(screen.get_width() // 2 - 200, y)))

    difficultyLeft = pygame.Rect(0, 0, 60, 60)
    difficultyLeft.center = (screen.get_width() // 2 - 60, y)
    pygame.draw.rect(screen, "gray", difficultyLeft)
    screen.blit(MM_font_30.render("<", False, "white"), MM_font_30.render("<", False, "white").get_rect(center=difficultyLeft.center))

    difficultyRight = pygame.Rect(0, 0, 60, 60)
    difficultyRight.center = (screen.get_width() // 2 + 60, y)
    pygame.draw.rect(screen, "gray", difficultyRight)
    screen.blit(MM_font_30.render(">", False, "white"), MM_font_30.render(">", False, "white").get_rect(center=difficultyRight.center))

    # placeholder value display
    val = MM_font_30.render(str(difficulty), False, "black")
    screen.blit(val, val.get_rect(center=(screen.get_width() // 2, y)))

    y += 120

    # FPS  ---------------------------------------------------
    label = MM_font_30.render("FPS:", False, "black")
    screen.blit(label, label.get_rect(center=(screen.get_width() // 2 - 200, y)))

    fpsButton60 = pygame.Rect(0, 0, 120, 60)
    fpsButton60.center = (screen.get_width() // 2 - 60, y)
    if FPS == 60:
        pygame.draw.rect(screen, "green", fpsButton60)
    else:
        pygame.draw.rect(screen, "gray", fpsButton60)
    screen.blit(MM_font_30.render("60", False, "white"),
                MM_font_30.render("60", False, "white").get_rect(center=fpsButton60.center))

    fpsButton144 = pygame.Rect(0, 0, 120, 60)
    fpsButton144.center = (screen.get_width() // 2 + 60, y)
    if FPS == 144:
        pygame.draw.rect(screen, "green", fpsButton144)
    else:
        pygame.draw.rect(screen, "gray", fpsButton144)
    screen.blit(MM_font_30.render("144", False, "white"),
                MM_font_30.render("144", False, "white").get_rect(center=fpsButton144.center))

    y += 120

    # PARTICLES ----------------------------------------------
    label = MM_font_30.render("Particles:", False, "black")
    screen.blit(label, label.get_rect(center=(screen.get_width() // 2 - 200, y)))

    particlesToggle = pygame.Rect(0, 0, 200, 60)
    particlesToggle.center = (screen.get_width() // 2 + 20, y)
    if particlesDisabled:
        pygame.draw.rect(screen, "red", particlesToggle)
        ptxt = MM_font_30.render("Disabled", False, "white")
    else:
        pygame.draw.rect(screen, "green", particlesToggle)
        ptxt = MM_font_30.render("Enabled", False, "white")
    screen.blit(ptxt, ptxt.get_rect(center=particlesToggle.center))

    y += 120

    # DEBUG ---------------------------------------------------
    label = MM_font_30.render("Debug Mode:", False, "black")
    screen.blit(label, label.get_rect(center=(screen.get_width() // 2 - 200, y)))

    debugToggle = pygame.Rect(0, 0, 200, 60)
    debugToggle.center = (screen.get_width() // 2 + 20, y)
    if not debug_mode:
        pygame.draw.rect(screen, "red", debugToggle)
        dtxt = MM_font_30.render("Disabled", False, "white")
    else:
        pygame.draw.rect(screen, "green", debugToggle)
        dtxt = MM_font_30.render("Enabled", False, "white")
    screen.blit(dtxt, dtxt.get_rect(center=debugToggle.center))
