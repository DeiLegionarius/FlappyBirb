version = "RELEASE v1.0.0 - 12/1/2025"

import random
import os
import sys
import subprocess
import pygame
        


# My libraries
from Essentials import menu
from Essentials import particle_engine as PE

pygame.font.init()


# [CONFIG]
Difficulty = 2
FPS = 144 # Max fps for stable gameplay is 144
def reset_config():
    global SpawnDelay, JumpPower, ObstacleSpeed, gravity, player_vel_y
    SpawnDelay = 4
    JumpPower = 500
    gravity = 900
    ObstacleSpeed = 125 * Difficulty
    
    player_vel_y = 0
    
reset_config()

if "-noclip" in sys.argv:
    noclip = True
else:
    noclip = False

if "-iskra_mode" in sys.argv:
    iskra_mode = True
else:
    iskra_mode = False

# pygame setup
pygame.init()
screen = pygame.display.set_mode((1280, 720))
pygame.display.set_caption("Flappy Birb")
clock = pygame.time.Clock()
running = True
dt = 0
jump_delay = 0
my_font = pygame.font.SysFont('Source Sans', 50)
gameover_font = pygame.font.SysFont('Source Sans', 60)
vfont = pygame.font.SysFont('Inter', 15)
time = 0
text_surface = my_font.render('Time: 0', False, (0, 0, 0))
score_text = my_font.render("Score: 0", False, (0, 0, 0))
gameover_text = my_font.render("Game Over!", False, (0, 0, 0,))
obstacles = []
clouds = []
time2 = -SpawnDelay
alive = True
score = 0
start_time = pygame.time.get_ticks()
scoreCooldown = 0
mainMenu = True
info = False
shop = False
settings = False
debug_mode = False

version_text = vfont.render(version, False, (0, 0, 0))
version_text.set_alpha(70)

player_pos = pygame.Vector2(screen.get_width() / 2, screen.get_height() / 2)
player_pos.x -= 300

# Asset Initialization
if hasattr(sys, "_MEIPASS"):
    asset_folder = os.path.join(sys._MEIPASS, "Assets")
else:
    asset_folder = os.path.join(os.path.dirname(__file__), "Assets")
asset_folder = os.path.join(os.path.dirname(__file__), "Assets")
MainMenuCover = pygame.image.load(os.path.join(asset_folder, "MainMenuCover.png"))
MainMenuCover = pygame.transform.scale(MainMenuCover, (1200, 720))
iskraBackground = pygame.image.load(os.path.join(asset_folder, "iskraOdzadje.jpg"))
iskraLogo = pygame.image.load(os.path.join(asset_folder, "LogoSTS.jpg"))
pipeTexture = pygame.image.load(os.path.join(asset_folder, ("pipe.png")))
if iskra_mode:
    pipeTexture = pygame.image.load(os.path.join(asset_folder, ("urnik" + str(random.randint(1, 5)) + (".png"))))
pipeTexture = pygame.transform.scale(pipeTexture, (100, 1000))
cloud_image = pygame.image.load(os.path.join(asset_folder, f"cloud1.png"))

# Player setup
essentials_folder = os.path.join(os.path.dirname(__file__), "Essentials")
def initialize_player():
    global birb_upflap, birb_midflap, birb_downflap, player_rect
    birb_upflap_path = os.path.join(asset_folder, "birb_upflap.png")
    birb_downflap_path = os.path.join(asset_folder, "birb_downflap.png")
    birb_midflap_path = os.path.join(asset_folder, "birb_midflap.png")
    birb_upflap = pygame.image.load(birb_upflap_path)
    birb_downflap = pygame.image.load(birb_downflap_path)
    birb_midflap = pygame.image.load(birb_midflap_path)
    birb_upflap = pygame.transform.scale(birb_upflap, (110, 80))
    birb_downflap = pygame.transform.scale(birb_downflap, (110, 80))
    birb_midflap = pygame.transform.scale(birb_midflap, (110, 80))
    player_rect = birb_upflap.get_rect(topleft=(player_pos.x, player_pos.y))

initialize_player()
pygame.display.set_icon(birb_upflap)

def add_obstacle(x, y, width, height):
    global obstacles, pipeTexture
    rect = pygame.Rect(x, y, width, height)
    obstacles.append((rect, pipeTexture))

def CreateNewObstaclePair():
    holeCenter = random.randint(screen.get_height() // 4, screen.get_height() - (screen.get_height() // 4))
    add_obstacle(screen.get_width(), holeCenter + 150, 100, 1000)
    add_obstacle(screen.get_width(), holeCenter - 1150, 100, 1000)
    
def CreateNewCloudDecal():
    global clouds, cloud_image
    cloud_rect = cloud_image.get_rect(topleft=(screen.get_width() - 50, random.randint(-500, 500)))
    if iskra_mode:
        cloud_image = iskraLogo
        cloud_rect = cloud_image.get_rect(topleft=(screen.get_width() - 50, random.randint(-500, -100)))
    clouds.append((cloud_image, cloud_rect))
     
def start_game():
    global alive, mainMenu, scoreCooldown, clouds, score, time2, obstacles, player_pos, start_time, jump_delay
    reset_config()
    player_vel_y = 0
    scoreCooldown = 0
    jump_delay = 0
    clouds = []
    score = 0
    time2 = -SpawnDelay
    obstacles = []
    player_pos = pygame.Vector2(screen.get_width() / 2, screen.get_height() / 2)
    player_pos.x -= 300
    start_time = pygame.time.get_ticks()
    alive = True
    mainMenu = False
    
def debug_text(content, location):
    if debug_mode:
        text = my_font.render(content, False, (0, 0, 0,))
        screen.blit(text, location)
    
while running:
    
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False
        if event.type == pygame.MOUSEBUTTONUP:
            pos = pygame.mouse.get_pos()
            if menu.playButton.collidepoint(pygame.mouse.get_pos()) and mainMenu and not info and not settings:
                initialize_player()
                start_game()
            if menu.infoButton.collidepoint(pygame.mouse.get_pos()) and mainMenu and not info and not settings:
                info = True
            if menu.backButton.collidepoint(pygame.mouse.get_pos()):
                info = False
                settings = False
                mainMenu = True
            if menu.settingsButton.collidepoint(pygame.mouse.get_pos()) and mainMenu and not info:
                settings = True
            
            # Settings
            if menu and settings:
                try:
                    if hasattr(menu, "difficultyLeft") and menu.difficultyLeft.collidepoint(pygame.mouse.get_pos()):
                        if Difficulty > 1:
                            Difficulty -= 1
                    if hasattr(menu, "difficultyRight") and menu.difficultyRight.collidepoint(pygame.mouse.get_pos()):
                        if Difficulty < 5:
                            Difficulty += 1
                            
                    if menu.fpsButton60.collidepoint(pygame.mouse.get_pos()):
                        FPS = 60
                        
                    if menu.fpsButton144.collidepoint(pygame.mouse.get_pos()):
                        FPS = 144
                        
                    if menu.particlesToggle.collidepoint(pygame.mouse.get_pos()):
                        if PE.PARTICLESDISABLEDCHECK():
                            PE.ENABLEPARTICLES()
                        else:
                            PE.DISABLEPARTICLES()

                    if menu.debugToggle.collidepoint(pygame.mouse.get_pos()):
                        if debug_mode:
                            debug_mode = False
                        else:
                            debug_mode = True
                except:
                    pass

    
    if mainMenu == True:
        if info:
            menu.INFOSCREEN(screen)
        elif settings:
            menu.SETTINGSINTERFACE(screen, Difficulty, FPS, PE.PARTICLESDISABLEDCHECK(), debug_mode)
        else:
            menu.CONSTRUCT_MENU(screen, MainMenuCover)
    
    if alive == True and mainMenu == False:
        
        screen.fill("aqua")
        if iskra_mode:  screen.blit(iskraBackground, (0, -500))
        player_vel_y += gravity * dt
        player_pos.y += player_vel_y * dt
        if player_pos.y > 700 or player_pos.y < -150:
            alive = False
        rotateByVel = -(player_vel_y / 10)
        if 100 >= player_vel_y >= -100:
            birb_current_image = birb_midflap
        elif player_vel_y < -100:
            birb_current_image = birb_downflap
        elif player_vel_y > 100:
            birb_current_image = birb_upflap
        rotated_image = pygame.transform.rotate(birb_current_image, rotateByVel)
        # player_rect = rotated_image.get_rect(center=(player_pos.x, player_pos.y))
        player_mask = pygame.mask.from_surface(rotated_image)
        
        if jump_delay > 0:
            jump_delay -= (20 * dt)
        if clouds == []:
            CreateNewCloudDecal()
        for cloud_image, cloud_rect in clouds:
            if cloud_rect.x < -1900:
                cloud_rect.topleft = screen.get_width() - 50, random.randint(-500, -100)
            else:
                cloud_rect.x -= 50 * dt
                if iskra_mode:  cloud_rect.x -= 150 * dt
                screen.blit(cloud_image, cloud_rect)
            
            
        if obstacles == []:
            CreateNewObstaclePair()
        
        new_obstacles = []
        for rect, pipeTexture in obstacles:
            rect.x -= ObstacleSpeed * dt
            
            obstacle_surface = pygame.Surface((rect.width, rect.height))  # Make a temporary surface for the obstacle
            obstacle_surface.fill("green")  # Fill it with a color (you can match the color of your obstacle)
            obstacle_mask = pygame.mask.from_surface(obstacle_surface)
            
            if player_pos.x in range(rect.x - 10, rect.x + 10):
                if not timeMS - 200 <= scoreCooldown or score == 0:
                    score += 1
                    ObstacleSpeed += 5 * Difficulty
                    scoreCooldown = timeMS
            if rect.x in range(700 + (3 * Difficulty), 710 + (3 * Difficulty)) and not timeMS - 100 <= time2:
                CreateNewObstaclePair()
                time2 = timeMS
            if player_mask.overlap(obstacle_mask, (rect.x - player_pos.x, rect.y - player_pos.y)) and not noclip:
                alive = False
                PE.CLEARPARTICLES()
            if rect.x >= -100:
                new_obstacles.append((rect, pipeTexture))
            # pygame.draw.rect(screen, "green", rect)
            screen.blit(pipeTexture, rect)
            if debug_mode and rect.y > 0:
                debug_text("Obstacle", rect)
            elif debug_mode and rect.y < 0:
               debug_text("Obstacle", (rect.x, rect.y + rect.height - 50))
            
        obstacles = new_obstacles
        
        keys = pygame.key.get_pressed()
        if keys[pygame.K_SPACE] and jump_delay <= 0:
            player_vel_y = -JumpPower
            PE.CREATEJUMPPARTICLES(player_rect, 60, 10, "white", 60, timeMS, 0.7, True) # location, amount, size, color, speed, currentTime, lifeTime
            jump_delay = jump_delay + 15
            
        
        
        time = (pygame.time.get_ticks() - start_time) // 1000
        timeMS = pygame.time.get_ticks() - start_time
        time_text = my_font.render(f'Time: {time}', False, (0, 0, 0))
        score_text = my_font.render(f'Score: {int(score)}', False, (0, 0, 0))
        player_rect.topleft = (player_pos.x, player_pos.y)
        # if debug_mode: pygame.draw.rect(screen, "red", player_rect)
        screen.blit(rotated_image, player_pos)
        PE.MOVE_AND_DRAW_PARTICLES("JumpParticles", dt, timeMS, ObstacleSpeed)
        debug_text("Player", player_pos)
        screen.blit(time_text, (0,0))
        screen.blit(score_text, (150,0))
    
    elif alive == False and mainMenu == False:
        screen.fill("aqua")
        for cloud_image, cloud_rect in clouds:
            screen.blit(cloud_image, cloud_rect)
        for rect, pipeTexture in obstacles:
            # pygame.draw.rect(screen, "green", rect)
            screen.blit(pipeTexture, rect)
        screen.blit(rotated_image, player_pos)
        screen.blit(time_text, (0,0))
        screen.blit(score_text, (150,0))
        gameover_text = gameover_font.render("Game Over!", False, (0, 0, 0,))
        gameover_text_rect = gameover_text.get_rect(center=(screen.get_width() // 2, screen.get_height() // 2))
        screen.blit(gameover_text, gameover_text_rect.topleft)
        text_surface = my_font.render("Press [Space] to restart!", False, (0, 0, 0))
        text_surface_rect = text_surface.get_rect(center=(screen.get_width() // 2, screen.get_height() // 2 + 100))
        screen.blit(text_surface, text_surface_rect.topleft)
        keys = pygame.key.get_pressed()
        menu.Speed_I_Need_A_Back_Button_My_Mom_Is_Kinda_Backbuttonless(screen, "MENU", screen.get_width() - 130, screen.get_height() // 2 + 300)
        if keys[pygame.K_SPACE]:
            start_game()

    FPStext = my_font.render(f'FPS: {int(clock.get_fps())}', False, (0, 0, 0))
    if debug_mode: screen.blit(FPStext, (300, 0))
    screen.blit(version_text, (0, screen.get_height() - 15))
    dt = clock.tick(FPS) / 1000
    pygame.display.flip()
pygame.quit()